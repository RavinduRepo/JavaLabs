import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Student {
    private String name;
    public String surname;
int attendance;
int MAX;
    public Student(String name){
            this.name=name;
            attendance=0;
            this.name=surname;

    }

}
