public class Lab03PartA
{
    public static void main(String args[])
    {
		//Implemnt Lab03PartA
	}
	
}
	