public class Lab03PartB
{
    public static void main(String args[])
    {
		//Implemnt Lab03PartB
	}
	
	public void findAdjacentsByArray(int index)
	{
		//Implemnt Lab03PartB a 
	}
	
	public void findAdjacentsByMap(int index)
	{
		//Implemnt Lab03PartB b
	}
	
}
	